//
//  ViewController.swift
//  SwiftyCompanion
//
//  Created by Jeanette Henriette BURGER on 2018/10/15.
//  Copyright © 2018 Jeanette Henriette BURGER. All rights reserved.
//

import UIKit
import SwiftyJSON

var code: String = "code"
var accessToken: String = "token"

var token: String = ""

var userToken: String = ""
var uname: String = ""
var uid: String = ""

struct Message: Decodable {
    let id: Int
    let login: String
    let url: String

}

///////// JOHANNESBURG /campus.id = 5


class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(patternImage: #imageLiteral(resourceName: "WTC_bg"))
        let apiCall = ApiController(); //called from ApiController.swift
        apiCall.getToken();
        print("this is token \(token)")
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBOutlet weak var searchInput: UITextField!
    
    @IBAction func searchButton(_ sender: UIButton) {

        getUser(1)
        getUserInfo(uid: uid)

    }
    
    func getUser(_ page: Int) {
//        var request = URLRequest(url: URL(string: "https://api.intra.42.fr/v2/users?access_token=" + (token) + "&page=\(page)")!)
        var request = URLRequest(url: URL(string: "https://api.intra.42.fr/v2/campus/5/users?access_token=" + (token) + "&page=\(page)")!) // -- to find jhb only students
//        var request = URLRequest(url: URL(string: "https://api.intra.42.fr/v2/users/rburger?access_token=" + (token) + "&page=\(page)")!)
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            (data, response, error) in
            //                    print(response as Any)
            if error != nil {
                print(error as Any)
            } else {
                guard let data = data else { return }
                
                if let httpResponse = response as? HTTPURLResponse {
                    if httpResponse.statusCode == 200 {
                        do {
                            
                            print("enter d = data. this is response")
                            print(response as Any)
                            print("this is data")
                            print(data as Any)
                            //save data here?
                            let _messages = try JSONDecoder().decode([Message].self, from: data)
                            for message in _messages{
                                //                                Data.messages.append(message)
                                DispatchQueue.main.async {
                                    
                                    if message.login == self.searchInput.text! {
                                        uid = String(message.id)
                                        print("Username found: \(message.login)")

                                    }
                                }

                                print("hererererere", message.login)

                            }
                            print("json finished")

                            
                        }
                        catch (let err) {
                            print(err)
                        }
                    }
                }
            }
        }
        task.resume()
//        return true
    }

    func getUserInfo(uid: String) {
        //        var request = URLRequest(url: URL(string: "https://api.intra.42.fr/v2/users?access_token=" + (token) + "&page=\(page)")!)
//        var request = URLRequest(url: URL(string: "https://api.intra.42.fr/v2/campus/5/users?access_token=" + (token) + "&page=\(page)")!) // -- to find jhb only students
                var request = URLRequest(url: URL(string: "https://api.intra.42.fr/v2/users/" + (uid) + "?access_token=" + (token))!)
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            (data, response, error) in
            print(response as Any)
            if error != nil {
                print(error as Any)
            }
            else if let d = data {
                do {
                    print("enter d = data in getUserInfo")
                    print(data)
                    if let dic = try JSONSerialization.jsonObject(with: d, options: JSONSerialization.ReadingOptions.mutableContainers) as? [Any] {
                        print("this is dic: ")
                        print(dic)
                        for message in dic {
                            //                                Data.messages.append(message)
                            DispatchQueue.main.async {
                                    print("data: \(message)")
                                    //                                        return true
                                }
                            }
                        }
            }
            catch (let err) {
                print(err)
            }
            }
        }
        task.resume()
//        return true
    }
}

